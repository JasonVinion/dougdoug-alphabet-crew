document.addEventListener('DOMContentLoaded', function() {
    const normalNameButton = document.getElementById('normalNameMode');
    const iconModeButton = document.getElementById('iconMode');
    const nameChangeModeButton = document.getElementById('nameChangeMode');

    normalNameButton.addEventListener('click', function() {
        browser.tabs.query({active: true, currentWindow: true}, function(tabs) {
            browser.tabs.sendMessage(tabs[0].id, { mode: "normalName" });
        });
    });

    iconModeButton.addEventListener('click', function() {
        browser.tabs.query({active: true, currentWindow: true}, function(tabs) {
            browser.tabs.sendMessage(tabs[0].id, { mode: "icon" });
        });
    });

    nameChangeModeButton.addEventListener('click', function() {
        browser.tabs.query({active: true, currentWindow: true}, function(tabs) {
            browser.tabs.sendMessage(tabs[0].id, { mode: "nameChange" });
        });
    });
});

function modifyUsername(username) {
    const firstLetter = username.charAt(0).toLowerCase();
    // Categorize as 'Z Crew' if the first character is not a letter or is in the second half of the alphabet
    return (!firstLetter.match(/[a-m]/i)) ? `Z Crew` : `A Crew`;
}

function scanAndUpdateUsernames() {
    const chatMessages = document.querySelectorAll('.chat-line__message');
    chatMessages.forEach(message => {
        const usernameElement = message.querySelector('.chat-author__display-name');
        if (usernameElement) {
            usernameElement.innerText = modifyUsername(usernameElement.innerText);
        }
    });
}

// MutationObserver to handle dynamic content
const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
            if (node.classList && node.classList.contains('chat-line__message')) {
                const usernameElement = node.querySelector('.chat-author__display-name');
                if (usernameElement) {
                    usernameElement.innerText = modifyUsername(usernameElement.innerText);
                }
            }
        });
    });
});

// Select the element that contains chat messages
const chatContainer = document.querySelector('.chat-scrollable-area__message-container');
if (chatContainer) {
    observer.observe(chatContainer, { childList: true, subtree: true });
}

// Initial scan
scanAndUpdateUsernames();

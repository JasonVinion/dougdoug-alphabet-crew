// Global variable for mode
let mode = "nameChange"; // Default mode

// Function to listen for messages from the popup
browser.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.mode === "icon" || message.mode === "nameChange" || message.mode === "normalName") {
        mode = message.mode;
        scanAndUpdateUsernames();
    }
});

// Function to modify the username
function modifyUsername(usernameElement) {
    const originalUsername = usernameElement.dataset.originalUsername || usernameElement.textContent;
    usernameElement.dataset.originalUsername = originalUsername; // Store original username if not already stored

    // Clear existing elements except the stored original username
    usernameElement.innerHTML = '';

    if (mode === "icon") {
        // Append the original username text
        usernameElement.textContent = originalUsername;

        // Create and append the crew icon
        const icon = document.createElement('img');
        icon.src = browser.runtime.getURL(`icons/${determineCrewIconName(originalUsername)}.webp`);
        icon.classList.add('crew-icon');
        icon.alt = 'Crew Icon'; // Alternative text for accessibility
        icon.style.marginLeft = '4px'; // Space between text and icon
        icon.style.width = '20px'; // Set the width of the icon
        icon.style.height = 'auto'; // Set the height to auto to maintain aspect ratio
        usernameElement.appendChild(icon);
    } else if (mode === "nameChange") {
        // Change the username to "A Crew" or "Z Crew"
        usernameElement.textContent = determineCrewIconName(originalUsername).replace('_', ' ');
    } else if (mode === "normalName") {
        // Reset to the original username without any icon
        usernameElement.textContent = originalUsername;
    }
}

// Helper function to determine "A_Crew" or "Z_Crew" based on the username
function determineCrewIconName(username) {
    const firstLetter = username.charAt(0).toLowerCase();
    return (firstLetter < 'n' && firstLetter.match(/[a-z]/i)) ? 'A_Crew' : 'Z_Crew';
}



// Function to scan and update usernames
function scanAndUpdateUsernames() {
    const chatMessages = document.querySelectorAll('.chat-line__message');
    chatMessages.forEach(message => {
        const usernameElement = message.querySelector('.chat-author__display-name');
        if (usernameElement) {
            const originalUsername = usernameElement.textContent; // Fetch the original username
            modifyUsername(usernameElement, originalUsername);
        }
    });
}

// MutationObserver for dynamic content
const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
            // Check if the added node is a Twitch chat message
            if (node.nodeType === Node.ELEMENT_NODE && node.classList.contains('chat-line__message')) {
                // Find the username element within the chat message
                const usernameElement = node.querySelector('.chat-author__display-name');
                if (usernameElement) {
                    // Store the original username if it hasn't been stored yet
                    if (!usernameElement.dataset.originalUsername) {
                        usernameElement.dataset.originalUsername = usernameElement.textContent;
                    }
                    // Apply the current mode to the new username element
                    modifyUsername(usernameElement, usernameElement.dataset.originalUsername);
                }
            }
        });
    });
});

// Select chat container and start observer
const chatContainer = document.querySelector('.chat-scrollable-area__message-container');
if (chatContainer) {
    observer.observe(chatContainer, { childList: true, subtree: true });
}

// Initial setup
scanAndUpdateUsernames();
